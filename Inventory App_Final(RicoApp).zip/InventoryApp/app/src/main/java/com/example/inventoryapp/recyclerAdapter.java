package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import android.content.Intent;
//  This class controls the recycleerview and it's elements
public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.MyVewiHolder> {
    private List<Products> productList;

    public recyclerAdapter(List<Products> productList){
        this.productList=productList;
    }

// All the elements in the view
    public class MyVewiHolder extends RecyclerView.ViewHolder {
        private final View view;
        private TextView nameTx;
        private TextView qtyTx;
        private TextView idTx;
        private Button addSubtract;
        private Button delete;


//The recycleview main
        public MyVewiHolder(@NonNull View view) {
            super(view);
            this.view =view;
            nameTx = view.findViewById(R.id.productName);
            qtyTx = view.findViewById(R.id.producQuantity);
            idTx = view.findViewById(R.id.productID);
            addSubtract = view.findViewById(R.id.buttonQuantity);
            delete = view.findViewById(R.id.buttonDelete);

            ProductDatabase productDatabase=new ProductDatabase(delete.getContext());
            // Deletes items off of the recyclerview
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String id = idTx.getText().toString();
                    productDatabase.deleteProduct(id);
                    Intent myIntent = new Intent(delete.getContext(), pageRefreash.class);
                    delete.getContext().startActivity(myIntent);
                }
            });
            //This calls the add activity
            addSubtract.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String id= idTx.getText().toString();
                    String qty = qtyTx.getText().toString();
                    Intent myIntent = new Intent(addSubtract.getContext(), editQuantity.class);
                    myIntent.putExtra("idTx", id);//The Add Activity will need these to work
                    myIntent.putExtra("qtyTx", qty);//.putExtra passes them over to it.
                    addSubtract.getContext().startActivity(myIntent);
                }
            });
        }

        public void setData(String name, int qty, int ID) {
            nameTx.setText(name);
            qtyTx.setText(String.valueOf(qty));
            idTx.setText(String.valueOf(ID));

        }
    }

    @NonNull
    @Override
    public MyVewiHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_list,parent, false);
        return new MyVewiHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyVewiHolder holder, int position) {
        String name = productList.get(position).getName();
        int qty = productList.get(position).getQty();
        int iD = productList.get(position).getId();
        holder.setData(name, qty, iD);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }
}