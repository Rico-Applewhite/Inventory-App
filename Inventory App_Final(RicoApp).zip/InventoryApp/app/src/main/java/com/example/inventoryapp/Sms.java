package com.example.inventoryapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
// Notification class, need to be implmented in a way that I can call it from activites.
public class Sms extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "o")
                .setSmallIcon(R.drawable.ic_baseline_exposure_zero_24)
                .setContentTitle("Out of Stock")
                .setContentText("An Item is out of Stock")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        notificationManger.notify(10,builder.build());

        Intent myIntent = new Intent(Sms.this, MainActivity2.class);
        Sms.this.startActivity(myIntent);
        Sms.this.finish();

    }

    NotificationManagerCompat notificationManger = NotificationManagerCompat.from(this);


    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name ="Out of Stock";
            String desctiption ="An Item is out of Stock";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("Outof", name, importance);
            channel.setDescription(desctiption);


            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
