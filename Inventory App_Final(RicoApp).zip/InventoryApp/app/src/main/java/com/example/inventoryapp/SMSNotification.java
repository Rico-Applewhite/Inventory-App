package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// give user permission or not to get Notifications
public class SMSNotification extends AppCompatActivity {
    Button buttonEnable;
    Button buttonDisable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsnotification);

        buttonEnable =findViewById(R.id.buttonEnable);
        buttonDisable =findViewById(R.id.buttonDisable);

        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("Notification", "Notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager= getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        buttonEnable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationCompat.Builder builder = new NotificationCompat.Builder(SMSNotification.this,"Notification" );
                builder.setContentTitle("Notification Enabled");
                builder.setContentText("You have enabled Inventory Notifications");
                builder.setSmallIcon(R.drawable.clipart163677);
                builder.setAutoCancel(true);

                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(SMSNotification.this);
                managerCompat.notify(1, builder.build());

                Intent myIntent = new Intent(SMSNotification.this, LoginActivity.class);
                SMSNotification.this.startActivity(myIntent);
                SMSNotification.this.finish();
            }
        });

        buttonDisable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                Intent myIntent = new Intent(SMSNotification.this, LoginActivity.class);
                SMSNotification.this.startActivity(myIntent);
                SMSNotification.this.finish();
            }
        });
    }
}