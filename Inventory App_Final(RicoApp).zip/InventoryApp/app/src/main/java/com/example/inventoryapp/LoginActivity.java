package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;


public class LoginActivity extends AppCompatActivity {
    private EditText passCodeEntry;
    private EditText userNameEntry;
    private Button Login;
    private Button Register;
    private TextView message;
    userDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        passCodeEntry = findViewById(R.id.PassCode);
        userNameEntry = findViewById(R.id.Username);
        message = findViewById(R.id.textView);
        Login = findViewById(R.id.buttonLogIn);
        Login.setEnabled(false);
        Register =findViewById(R.id.buttonRegister);
        Register.setEnabled(false);
        db= new userDatabase(this);
// addTextChangedListerner disables the two buttons until the user input something into both fields
        userNameEntry.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
//unlocks button after text changes
            @Override
            public void afterTextChanged(Editable editable) {
                if(passCodeEntry.getText().toString().matches("")||userNameEntry.getText().toString().matches("") ) {
                    Login.setEnabled(false);
                    Register.setEnabled(false);
                }
                else{
                    Login.setEnabled(true);
                    Register.setEnabled(true);}
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = userNameEntry.getText().toString();
                String passCode = passCodeEntry.getText().toString();
                //When the Register is press it checks the username against the database.If a
                //user has the name already and message will appear.
                boolean Taken = db.searchUser(userName);
                if (Taken == false) {
                    boolean added = db.addUser(userName, passCode);
                    if (added){
                        message.setText("Registration Successful");
                    }
                    else
                        message.setText("Registration Failed");
                }
                else
                    message.setText("Username is taken");
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = userNameEntry.getText().toString();
                String passCode = passCodeEntry.getText().toString();
                boolean checkPassed = db.searchUserPassword(userName,passCode);
                //When login is press, the userName and the passcode is check against the system.
                //Error message is displayed when either is incorrect.
                if (checkPassed){
                    message.setText("Welcome back "+userName+ ".");

                    //begins the next activity.
                    Intent myIntent = new Intent(LoginActivity.this, MainActivity2.class);
                    LoginActivity.this.startActivity(myIntent);
                    LoginActivity.this.finish();
                }
                else
                    message.setText("UserName/Password is incorrect.");


            }
        });
    }
}