package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
//This Class is used to refreash the main page and update the recyclerView
//TODO Implement a way to update the recyclerview without needing this.
public class pageRefreash extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.refreshpage);
        Intent myIntent = new Intent(pageRefreash.this, MainActivity2.class);
        pageRefreash.this.startActivity(myIntent);
        pageRefreash.this.finish();
    }
}
