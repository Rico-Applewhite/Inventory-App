package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// This Activity is an extention the add/subtract button. User
// will input a number
public class editQuantity extends AppCompatActivity {
    private EditText Amount;
    ProductDatabase productDatabase=new ProductDatabase(editQuantity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_quantity);
        Intent intent = getIntent();
        //The variables below was pulled from the recycler
        String ID = intent.getStringExtra("idTx");
        String current = intent.getStringExtra("qtyTx");

        Button addOn = findViewById(R.id.addQty);
        Button subOff = findViewById(R.id.subQty);
        Amount=findViewById(R.id.qtyChange);

        // Takes the User's input and adds to current Inventory
        addOn.setOnClickListener(view -> {
            String amount = Amount.getText().toString();
            if (Testvariable(amount)) { //Tests the user's input
                int newTotal = (Integer.parseInt(current) + Integer.parseInt(amount));
                productDatabase.update(ID, newTotal);
                Intent myIntent = new Intent(editQuantity.this, pageRefreash.class);
                editQuantity.this.startActivity(myIntent);
                editQuantity.this.finish();
            } else {
                Toast.makeText(editQuantity.this, "Invalid entry", Toast.LENGTH_SHORT).show();
            }
        });

        // Takes the User's input and subtracts from current Inventory
        subOff.setOnClickListener(view -> {
            String amount = Amount.getText().toString();
            if (Testvariable(amount)) {
                int newTotal = (Integer.valueOf(current) - Integer.valueOf(amount));
                productDatabase.update(ID, newTotal);
                Intent myIntent = new Intent(editQuantity.this, pageRefreash.class);
                editQuantity.this.startActivity(myIntent);
                editQuantity.this.finish();
            }
            else{
                    Toast.makeText(editQuantity.this, "Invalid input", Toast.LENGTH_SHORT).show();
                }
        });
    }
// The below function test if the user input is a vaild integer of
// not.
    private boolean Testvariable(String input) {
        try{
            Integer.parseInt(input);
            return true;
        }
        catch(NumberFormatException e) {
            return false;
        }
        }
    }
