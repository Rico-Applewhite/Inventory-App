package com.example.inventoryapp;

import static android.provider.Contacts.SettingsColumns.KEY;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
//user Database Helper
public class userDatabase extends SQLiteOpenHelper{

    private static final int DATABASE_VERSION=1;
    private static final String DATABASE_NAME= "userLogin";
    private static final String TABLE_USERS = "Users";
    private static final String KEY_USER = "username";
    private static final String KEY_PASSWORD = "password";

    public userDatabase(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create TABLE Users(username TEXT primary key, password TEXT)";
        db.execSQL(query);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i , int i1){
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_USERS);
    }
//CRUD Create Method to add Users
    public boolean addUser(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER, username);
        values.put(KEY_PASSWORD, password);

        long result=db.insert("Users", null, values);
        if(result == -1) return false;
        else
            return true;
    }
//CRUD read Method to search the database for user name
    boolean searchUser(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor= db.rawQuery("Select * from users where username =?", new String[] {username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
// search for username and password
    boolean searchUserPassword(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor= db.rawQuery("Select * from users where username =? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
//CRUD Method update the database
    public int update(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER, username);
        values.put(KEY_PASSWORD, password);

        return db.update(TABLE_USERS,values, KEY_USER+"=?", new String[]{String.valueOf((username))});
    }
//CRUD Method Delete to delete users
    public void deleteUser(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USERS, KEY_USER+ "=?", new String[]{String.valueOf(username)});
        db.close();
    }

}
