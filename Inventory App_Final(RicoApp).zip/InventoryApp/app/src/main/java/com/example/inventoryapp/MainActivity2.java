package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private List<Products> productList;
    private Button addProduct;
    private EditText searchtext;
    private Button search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        inData2();//Retrieves the database and store it into a list
        inRecyclerView();//begin recyclerView

        //Main Activity only has three buttons, the rest on screen is set in the recycler.
        addProduct = findViewById(R.id.buttonNewItem2);
        search = findViewById(R.id.lookupEnter);
        searchtext= findViewById(R.id.searchBar);

        //When the Add button is press, a new add activity starts.
        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity2.this, add.class);
                MainActivity2.this.startActivity(myIntent);
            }
        });

        //TODO Implement the Search Bar feature.
        //TODO Implement OutofStock Notification
    }

    //Retrieves Database into a list
    private void inData2() {
        ProductDatabase productDatabase= new ProductDatabase(MainActivity2.this);
        List<Products> everything = productDatabase.getEveryone();
        productList = everything;
        //ArrayAdapter productArrayAdapter = new ArrayAdapter<Products>(MainActivity2.this, android.R.layout.simple_list_item_1, everything);
    }

    //Creates RecyclerView
    public void inRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView);
        recyclerAdapter adapter = new recyclerAdapter(productList);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

    }
}