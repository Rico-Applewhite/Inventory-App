package com.example.inventoryapp;
//Products Class
public class Products {
    private int id;
    private String name;
    private int qty;

    //constructors

    public Products(int id, String name, int qty) {
        this.id = id;
        this.name = name;
        this.qty = qty;
    }

    public Products() {
    }

    //to string

    @Override
    public String toString() {
        return "Products{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", qty=" + qty +
                '}';
    }

    // getter and setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}