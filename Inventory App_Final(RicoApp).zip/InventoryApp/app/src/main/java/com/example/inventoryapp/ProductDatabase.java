package com.example.inventoryapp;

import android.content.ContentValues;

import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import android.content.Context;
//This is the Product Database helper
public class ProductDatabase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "Inventory";
    private static final String TABLE_PRODUCTS = "Products";
    private static final String KEY_NAME = "productName";
    private static final String KEY_QUANTITY = "productQuantity";
    private static final String COLUMN_ID = "ID";



    public ProductDatabase(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create TABLE Products(ID INTEGER PRIMARY KEY AUTOINCREMENT, productName TEXT, productQuantity INTERGER)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
    }
//CRUD create Method
    public boolean addProduct(Products products) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(KEY_NAME, products.getName());
        values.put(KEY_QUANTITY, products.getQty());

        long result = db.insert("Products", null, values);
        if (result == -1) return false;
        else
            return true;
    }

//CRUD Read Method need completeing for search bar use.
    public List<Products> searchproduct(String product) {
        List<Products> searchedList = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "SELECT * FROM " + TABLE_PRODUCTS;

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            do {
                if(cursor.getString(1)==product) {
                    int productID = cursor.getInt(0);
                    String productName = cursor.getString(1);
                    int productQty = cursor.getInt(2);

                    Products newProduct = new Products(productID, productName, productQty);
                    searchedList.add(newProduct);
                }
            } while (cursor.moveToNext());
        } else {

        }
        cursor.close();
        db.close();
        return searchedList;
    }

    //CRUD update Method
    public boolean update(String productID, int productQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_QUANTITY, productQuantity);

         db.update(TABLE_PRODUCTS, values, COLUMN_ID+"="+productID,null);
         return true;
    }
//CRUD Delete Method
    public void deleteProduct(String productID) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PRODUCTS, COLUMN_ID + "= " + productID,null);
        db.close();
    }

//CRUD ReadAll Method Get the Entire database list for the recycler view.
    public List<Products> getEveryone() {
        List<Products> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + TABLE_PRODUCTS;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            do {
                int productID = cursor.getInt(0);
                String productName = cursor.getString(1);
                int productQty = cursor.getInt(2);

                Products newProduct = new Products(productID, productName, productQty);
                returnList.add(newProduct);

            } while (cursor.moveToNext());
        } else {

        }
        cursor.close();
        db.close();
        return returnList;
    }

 //Tried to implement a way to get out of stock items out of the list and send a notification
/*
    public boolean getOutofStock() {
        String queryString = "SELECT * FROM " + TABLE_PRODUCTS;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            do {
                int productID = cursor.getInt(0);
                String productName = cursor.getString(1);
                int productQty = cursor.getInt(2);

                if (productQty==0) {
                    return true;
                } else {

                }
            } while (cursor.moveToNext());
        }
        else {

        }
        cursor.close();
        return false;
}*/


}

