package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
// This Class is used to Add new items to the database
public class add extends AppCompatActivity{

    private EditText newName;
    private EditText newQty;
    private Button Confirm;
    private Button Cancel;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);

        newName = findViewById(R.id.newProductN);
        newQty = findViewById(R.id.newProductQty);
        Confirm = findViewById(R.id.buttonConfirm);
        Cancel = findViewById(R.id.buttonCancel);

        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(add.this, MainActivity2.class);
                add.this.startActivity(myIntent);
                add.this.finish();
            }
        });
//When the Confirm button is pressed
        Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Products products;
                String notempty=  newName.getText().toString();
                String anumber= newQty.getText().toString();
                //Checks user's input
            if(notempty!=""&& Testvariable(anumber)) {
                products = new Products(-1, newName.getText().toString(), Integer.parseInt(newQty.getText().toString()));
                ProductDatabase productDatabase = new ProductDatabase(add.this);
                boolean success = productDatabase.addProduct(products);
            }
            //Closed this activity and goes back to the last
                Intent myIntent = new Intent(add.this, MainActivity2.class);
                add.this.finish();
                add.this.startActivity(myIntent);

            }
        });
    }

    // The below function test if the user input is a vaild integer of
// not.
    private boolean Testvariable(String input) {
        try{
            Integer.parseInt(input);
            return true;
        }
        catch(NumberFormatException e) {
            return false;
        }
    }
}